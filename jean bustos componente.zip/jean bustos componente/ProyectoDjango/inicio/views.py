from django.shortcuts import render

def home(request):
    contexto = {
        'titulo': 'Mi primera página Django',
        'mensaje': '¡Hola! Mi proyecto funciona correctamente.'
    }
    return render(request, 'inicio.html', contexto)
